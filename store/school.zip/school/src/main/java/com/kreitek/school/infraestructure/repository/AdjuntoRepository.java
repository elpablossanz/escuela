package com.kreitek.school.infraestructure.repository;

import com.kreitek.school.domain.entity.Adjunto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdjuntoRepository extends JpaRepository<Adjunto,Long> {
}
