package com.kreitek.school.infraestructure.rest;

import com.kreitek.school.application.dto.AdjuntoDto;
import com.kreitek.school.application.dto.LeccionDto;
import com.kreitek.school.application.service.LeccionService;
import com.kreitek.school.domain.entity.Leccion;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cursos/{cursoId}")
public class LeccionRestController {

    private final LeccionService leccionService;

    @Autowired
    public LeccionRestController(LeccionService leccionService){
        this.leccionService = leccionService;
    }

    @GetMapping(value = "/lecciones", produces = "application/json")
    public ResponseEntity<List<LeccionDto>> obtenerLeccionesDeCurso(@PathVariable Long cursoId){
       List<LeccionDto> leccionesDtos = leccionService.obtenerLeccionesDeUnCurso(cursoId);
       return new ResponseEntity<>(leccionesDtos, HttpStatus.OK);
    }

    @GetMapping(value = "/lecciones/{leccionId}", produces = "application/json")
    public ResponseEntity<LeccionDto> obtenerLeccion(@PathVariable Long cursoId, @PathVariable Long leccionId){
       return leccionService
                .obtenerLeccionDeUnCurso(cursoId, leccionId)
                .map(leccionDto -> new ResponseEntity(leccionDto, HttpStatus.OK))
                .orElse(new ResponseEntity(HttpStatus.NOT_FOUND));

    }

    @PostMapping(value = "lecciones", produces = "application/json", consumes = "application/json")
    public ResponseEntity<LeccionDto> crearLeccionEnCurso(@PathVariable Long cursoId, @RequestBody LeccionDto leccionDto){
       leccionDto = leccionService.crearLeccion(leccionDto, cursoId);
       return new ResponseEntity<>(leccionDto, HttpStatus.CREATED);
    }

    @PutMapping(value = "lecciones/{leccionId}/adjuntos", produces = "application/json", consumes = "application/json")
    public ResponseEntity<List<AdjuntoDto>> anadirAdjuntoEnLeccion(@PathVariable Long cursoId,
                                                                   @PathVariable Long leccionId,
                                                                   @RequestBody AdjuntoDto adjuntoDto){
        List<AdjuntoDto> adjuntoDtos = leccionService.adjuntarFichero(cursoId, leccionId, adjuntoDto);
        return new ResponseEntity<>(adjuntoDtos, HttpStatus.OK);

    }
}
