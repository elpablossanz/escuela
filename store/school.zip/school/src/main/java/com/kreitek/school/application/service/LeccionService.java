package com.kreitek.school.application.service;

import com.kreitek.school.application.dto.AdjuntoDto;
import com.kreitek.school.application.dto.LeccionDto;
import com.kreitek.school.domain.entity.Leccion;

import java.util.List;
import java.util.Optional;

public interface LeccionService {

    List<LeccionDto> obtenerLeccionesDeUnCurso(Long cursoId);
    LeccionDto crearLeccion(LeccionDto leccionDto, Long cursoId);
    Optional<LeccionDto> obtenerLeccionDeUnCurso(Long cursoId, Long leccionId);

    List<AdjuntoDto> adjuntarFichero(Long cursoId, Long leccionId, AdjuntoDto adjuntoDto);
}
